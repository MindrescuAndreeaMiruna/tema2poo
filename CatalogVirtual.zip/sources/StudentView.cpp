#include "../headers/StudentView.hpp"

#include <utility>

StudentView::StudentView(std::string viewName, bool isDisplayed, std::string username):
    View(std::move(viewName), isDisplayed), student{std::move(username)}{
    prompts.emplace_back(std::make_pair("Type 'exit' to sign out: ", ""));
}

std::vector<std::string> StudentView::display(){
    std::cout << student;

    std::string res;
    std::vector <std::string> options;

    std::cout << prompts[0].prompt;
    while(true){
        std::getline(std::cin, res);
        if(res == "exit")
            break;
        std::cout << prompts[0].prompt;
    }
    options.emplace_back("WelcomeView");
    return options;
}

std::string StudentView::listen(){
    return display()[0];
}