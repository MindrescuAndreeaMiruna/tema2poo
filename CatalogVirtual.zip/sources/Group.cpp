#include "../headers/Group.hpp"
#include <fstream>

Group::Group(const std::string& groupName): groupName(groupName){
    readFile("resources/groups/" + groupName + "Students.txt", students);
    readFile("resources/groups/" + groupName + "Professors.txt", professors);
    readFile("resources/groups/" + groupName + "Subjects.txt", subjects);
}

std::string Group::getGroupName(){
    return groupName;
}

void Group::readFile(const std::string& fileName, std::vector <std::string>& v){
    std::ifstream fin(fileName);
    for(std::string line; std::getline(fin, line);)
        v.emplace_back(line);
    fin.close();
}

void Group::writeFile(const std::string& fileName, std::vector <std::string>& v){
    std::ofstream fout(fileName);
    for(const auto& line: v)
        fout << line << "\n";
    fout.close();
}

void Group::addStudent(const std::string& studentUsername){
    students.emplace_back(studentUsername);
}

void Group::addProfessor(const std::string& professorUsername){
    professors.emplace_back(professorUsername);
}

void Group::addSubject(const std::string& subjectName){
    subjects.emplace_back(subjectName);
}

void findSubject(const std::string&); //subjectName


Group::~Group(){
    writeFile("resources/groups/" + groupName + "Students.txt", students);
    writeFile("resources/groups/" + groupName + "Professors.txt", professors);
    writeFile("resources/groups/" + groupName + "Subjects.txt", subjects);
}