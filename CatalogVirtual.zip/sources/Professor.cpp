#include "../headers/Professor.hpp"
#include <iostream>
#include <fstream>
#include <utility>

Professor::Professor(std::string username): username(std::move(username)) {
    readFile();
}

void Professor::readFile(){
    std::string fileName = "resources/professors/" + username + ".txt";
    std::ifstream fin(fileName);
    std::getline(fin, subject);
    for(std::string line; std::getline(fin, line); )
        groups.emplace_back(line);
    fin.close();
}

std::string Professor::getUsername() const{
    return username;
}

std::string Professor::getSubject() const {
    return subject;
}

std::vector <std::string> Professor::getGroups() const {
    return groups;
}

void Professor::addGroup(const std::string& group){
    groups.emplace_back(group);
    std::string fileName = "resources/professors/" + username + ".txt";
    std::ofstream fout(fileName, std::ios::app);
    fout << group << "\n";
    fout.close();

    fileName = "resources/groups/" + group + "Professors.txt";
    fout = std::ofstream(fileName, std::ios::app);
    fout << username << "\n";
    fout.close();

    fileName = "resources/groups/" + group + "Subjects.txt";
    fout = std::ofstream(fileName, std::ios::app);
    fout << subject << "\n";
    fout.close();
}