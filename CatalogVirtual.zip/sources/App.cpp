#include <iostream>
#include "../headers/ProfessorView.hpp"
#include "../headers/StudentView.hpp"
#include "../headers/WelcomeView.hpp"
#include "../headers/SignInView.hpp"
#include "../headers/SignUpView.hpp"
#include "../headers/App.hpp"

App::App(){
    views.emplace_back(new WelcomeView{"WelcomeView", true});
    views.emplace_back(new SignInView{"SignInView", false});
    views.emplace_back(new SignUpView{"SignUpView", false});
}

void App::changeView(const std::string& message){
    if(message.substr(0, 11) == "StudentView") {
        views.emplace_back(new StudentView{"StudentView", true, message.substr(12)});
        return;
    }
    if(message.substr(0, 13) == "ProfessorView") {
        views.emplace_back(new ProfessorView{"ProfessorView", true, message.substr(14)});
        return;
    }
    if(message == "WelcomeView" && views.size() == 4){
        delete views[3];
        views.pop_back();
    }
    for (auto &view: views)
        if (view->getViewName() == message) {
            view->setIsDisplayed(true);
            return;
        }
}

void App::run(){
    std::cout << "CatalogVirtual started\n\n";

    while(true){
        std::string message;
        for(auto& view: views)
            if(view->getIsDisplayed()) {
                message = view->listen();
                if(message == "Exit")
                    return;
                view->setIsDisplayed(false);
                changeView(message);
            }
    }
}

App::~App(){
    for(const auto& view: views)
        delete view;
}
