#include "../headers/WelcomeView.hpp"

#include <utility>

WelcomeView::WelcomeView(std::string viewName, bool isDisplayed): View(std::move(viewName), isDisplayed) {
    prompts.emplace_back(std::make_pair("Welcome to CatalogVirtual", ""));
    prompts.emplace_back(std::make_pair("Type 1 to Sign In", "SignInView"));
    prompts.emplace_back(std::make_pair("Type 2 to Sign Up", "SignUpView"));
    prompts.emplace_back(std::make_pair("Type 3 to Exit", "Exit"));
}

std::vector <std::string> WelcomeView::display(){
    std::vector <std::string> options;
    for(const auto& prompt: prompts)
        std::cout << prompt.prompt << "\n";
    std::string res;

    while(true){
        std::getline(std::cin, res);
        if(res == "1") {
            options.emplace_back(prompts[1].label);
            break;
        } else if(res == "2") {
            options.emplace_back(prompts[2].label);
            break;
        } else if(res == "3"){
            options.emplace_back(prompts[3].label);
            break;
        } else{
            std::cout << "The options are 1, 2 or 3. Choose one of them!\n";
        }
    }
    return options;
}

std::string WelcomeView::listen(){
    std::vector <std::string> res = display();
    return res[0];
}

