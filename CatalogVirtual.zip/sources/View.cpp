#include "../headers/View.hpp"

#include <utility>

View::View(std::string viewName, bool isDisplayed): viewName(std::move(viewName)), isDisplayed(isDisplayed){}

bool View::getIsDisplayed() const {
    return isDisplayed;
}

void View::setIsDisplayed(bool _isDisplayed) {
    isDisplayed = _isDisplayed;
}

std::string View::getViewName() const {
    return viewName;
}