#include "../headers/Subject.hpp"
#include "../headers/Exceptions.hpp"
#include <iostream>
#include <utility>

Subject::Subject(int credits, std::string subjectName): credits(credits), subjectName(std::move(subjectName)){}

int Subject::getCredits() const{
    return credits;
}

std::string Subject::getSubjectName() const {
    return subjectName;
}

std::vector <std::pair<std::string, float>> Subject::getGrades() const {
    return grades;
}

void Subject::validateLabel(const std::string& label) const{
    for(const auto& grade: grades)
        if(grade.first == label)
            throw invalid_input{"Please provide a unique label"};
}

void Subject::addGrade(const std::string& label, float grade){
    try{
        validateLabel(label);
        grades.emplace_back(std::make_pair(label, grade));
        grades.emplace_back(std::make_pair(label, grade));
        std::cout << "Grade with identifier " << label << " was added successfully";
    }
    catch(input_error& err){
        std::cout << err.what() << "\n";
    }
}

void Subject::deleteGrade(const std::string& label) {
    for(int i = 0; i < grades.size(); i ++)
        if(grades[i].first == label){
            grades.erase(grades.begin() + i);
            std::cout << "Grades with identifier " << label << " deleted successfully";
            return;
        }
    std::cout << "Nothing to delete";
}

float Subject::getAvgGrade() {
    float avg = 0;
    for(const auto& grade: grades)
        avg += grade.second;
    return avg / (float)grades.size();
}

std::ostream& operator<<(std::ostream& os, const Subject& subject){
    os << "\t" << subject.subjectName << "\n";
    for(const auto& grade: subject.grades)
        os << "\t\t" << grade.first << " " << grade.second << "\n";
    return os;
}