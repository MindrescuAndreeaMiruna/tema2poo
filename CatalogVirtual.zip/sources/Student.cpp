#include "../headers/Student.hpp"
#include <iostream>
#include <fstream>
#include <utility>

Student::Student(std::string username): username(std::move(username)){
    readFile();
}

std::map <std::string, std::string> Student::parseLine(std::string line) {
    std::string value;
    std::vector <std::string> gradeArr;

    while(line.length()){
        if(line[0] == ','){
            gradeArr.push_back(value);
            value.clear();
        } else {
            value.push_back(line[0]);
        }
        line.erase(line.begin());
    }
    gradeArr.push_back(value);

    std::map<std::string, std::string> grade;
    grade["label"] = gradeArr[0];
    grade["grade"] = gradeArr[1];
    return grade;
}

int Student::stringToInt(const std::string& s){
    int num = 0;
    for(const auto& ch: s)
        num = num * 10 + (int)(ch - '0');
    return num;
}

void Student::readFile(){
    std::string fileName = "resources/students/" + username + ".txt";
    std::ifstream fin(fileName);

    int credits, cntGrades;
    for(std::string subjectName; std::getline(fin, subjectName); ){
        fin >> credits;
        fin >> cntGrades;
        fin.get();
        auto *subject = new Subject{credits, subjectName};
        std::string line;
        for(int i = 0; i < cntGrades; i ++){
            std::getline(fin, line);
            std::map <std::string, std::string> options = parseLine(line);
            subject->addGrade(options["label"], (float)stringToInt(options["grade"]));
        }
        subjects.emplace_back(subject);
    }
    fin.close();
}

void Student::writeFile(){
    std::string fileName = "resources/students/" + username + ".txt";
    std::ofstream fout(fileName);
    for(const auto& subject: subjects){
        fout << subject->getSubjectName() << "\n";
        std::vector <std::pair <std::string, float> > grades = subject->getGrades();
        for(const auto& grade: grades)
            fout << grade.first << "," << grade.second << "\n";
    }
    fout.close();
}

void Student::addSubject(int credits, std::string subjectName){
    subjects.emplace_back(new Subject{credits, std::move(subjectName)});
}

void Student::addGrade(const std::string& subjectName, const std::string& label, float grade){
    for(auto& subject: subjects)
        if(subject->getSubjectName() == subjectName){
            subject->addGrade(label, grade);
            return;
        }
}

void Student::deleteGrade(const std::string& subjectName, const std::string& label){
    for(auto& subject: subjects)
        if(subject->getSubjectName() == subjectName){
            subject->deleteGrade(label);
            return;
        }
}

float Student::getAvgGrade() const{
    float studCredits = 0;
    int totalCredits = 0;
    for(const auto& subject: subjects){
        totalCredits += subject->getCredits();
        studCredits += (float)subject->getCredits() * subject->getAvgGrade() / 10.f;
    }
    return studCredits / (float)totalCredits * 10;
}

Student::~Student(){
    writeFile();
    for(auto& subject: subjects)
        delete subject;
}

std::ostream& operator<<(std::ostream& os, Student& student) {
    os << student.username << " has grades\n";
    for(const auto& subject: student.subjects)
        os << subject;
    os << "\tOverall average is: " << student.getAvgGrade() << "\n";
    return os;
}

