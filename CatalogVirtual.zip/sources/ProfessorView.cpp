#include "../headers/ProfessorView.hpp"
#include "../headers/Exceptions.hpp"
#include <utility>
#include <fstream>
#include <iostream>

ProfessorView::ProfessorView(std::string viewName, bool isDisplayed, std::string username): View(std::move(viewName), isDisplayed), professor(std::move(username)){
    prompts.emplace_back(std::make_pair("Type 'info' to see personal info", ""));
    prompts.emplace_back(std::make_pair("Type 'groupInfo <groupName>' to see the students of group <groupName>", ""));
    prompts.emplace_back(std::make_pair("Type 'join <groupName>' to become professor at group <groupName>", ""));
    prompts.emplace_back(std::make_pair("Type 'add <groupName> <studentUsername> <label> <grade>' to add a grade to a student. (All fields are mandatory and cannot contain spaces)", ""));
    prompts.emplace_back(std::make_pair("Type 'delete <groupName> <studentUsername> <label>' to delete a grade of student. (All fields are mandatory and cannot contain spaces)", ""));
    prompts.emplace_back(std::make_pair("Type 'exit' to sign out", ""));
}

std::vector <std::string> ProfessorView::parseLine(std::string line){
    std::string value;
    std::vector <std::string> options;

    while(line.length()){
        if(line[0] == ' '){
            options.push_back(value);
            value.clear();
        } else {
            value.push_back(line[0]);
        }
        line.erase(line.begin());
    }
    options.push_back(value);

    return options;
}

std::vector<std::string> ProfessorView::display(){
    for(const auto& prompt: prompts)
        std::cout << prompt.prompt << "\n";
    std::string res;
    std::getline(std::cin, res);
    return parseLine(res);
}

std::string ProfessorView::listen(){
    while(true){
        std::vector <std::string> options = display();
        if(options.size() == 1 && options[0] == "exit"){
            return "WelcomeView";
        } else if(options.size() == 1 && options[0] == "info"){
            showPersonalInfo();
        } else if(options.size() == 2 && options[0] == "groupInfo"){
            try{
                seeGroupInfo(options[1]);
            }
            catch(input_error &err){
                std::cout << err.what() << "\n";
            }
        } else if(options.size() == 2 && options[0] == "join"){
            try{
                joinGroup(options[1]);
            }
            catch(input_error &err){
                std::cout << err.what() << "\n";
            }
        } else if(options.size() == 5 && options[0] == "add"){
            try{
                addGrade(options);
            }
            catch(input_error &err){
                std::cout << err.what() << "\n";
            }
        } else if(options.size() == 4 && options[0] == "delete"){
            try{
                deleteGrade(options);
            }
            catch(input_error &err){
                std::cout << err.what() << "\n";
            }
        }
        std::cout << "\n";
    }
}

bool ProfessorView::findGroup(const std::string& groupName) {
    std::string fileName = "resources/groups.txt";
    std::ifstream fin(fileName);
    bool found = false;
    for(std::string line; std::getline(fin, line) && !found; )
        if(line == groupName)
            found = true;
    fin.close();
    return found;
}

void ProfessorView::showPersonalInfo() const {
    std::cout << "Username: " << professor.getUsername() << "\n";
    std::cout << "Subject: " << professor.getSubject() << "\n";
    std::vector <std::string> groups = professor.getGroups();
    for(const auto& group: groups)
        std::cout << group << "\n";
    std::cout << "\n";
}

void ProfessorView::seeGroupInfo(const std::string& groupName) {
    if(!findGroup(groupName))
        throw invalid_input{"This group doesn't exist"};

    std::string fileName = "resources/groups/" + groupName + "Students.txt";
    std::ifstream fin(fileName);
    for(std::string line; std::getline(fin, line); )
        std::cout << line << "\n";
    fin.close();
}

void ProfessorView::joinGroup(const std::string& groupName) {
    if(!findGroup(groupName)){
        std::string fileName = "resources/groups.txt";
        std::ofstream fout(fileName, std::ios::app);
        fout << groupName;
        fout.close();
        professor.addGroup(groupName);
    } else{
        std::string fileName = "resources/groups/" + groupName + "Subjects.txt";
        std::ifstream fin(fileName);
        bool found = false;
        for(std::string line; std::getline(fin, line) && !found; )
            if(line == professor.getSubject())
                found = true;
        fin.close();
        if(found)
            throw invalid_input{"Cannot add you to this group because your subject is already taught by another professor"};
        professor.addGroup(groupName);
    }
}

void ProfessorView::addGrade(const std::vector<std::string>&) {
    throw invalid_input{"This functionality is not implemented yet"};
}

void ProfessorView::deleteGrade(const std::vector<std::string>&) {
    throw invalid_input{"This functionality is not implemented yet"};
}