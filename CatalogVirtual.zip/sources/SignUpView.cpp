#include <fstream>
#include <utility>
#include "../headers/SignUpView.hpp"
#include "../headers/Exceptions.hpp"


SignUpView::SignUpView(std::string viewName, bool isDisplayed): View(std::move(viewName), isDisplayed){
    prompts.emplace_back(std::make_pair("Sign Up", ""));
    prompts.emplace_back(std::make_pair("Are you a Professor(p)/Student(s): ", "option"));
    prompts.emplace_back(std::make_pair("Name: ", "name"));
    prompts.emplace_back(std::make_pair("Username: ", "username"));
    prompts.emplace_back(std::make_pair("Password: ", "password"));
    prompts.emplace_back(std::make_pair("Group: ", "group"));
    prompts.emplace_back(std::make_pair("Subject: ", "subject"));
}

std::string SignUpView::acceptsInput(const std::string& prompt){
    std::string res;
    std::cout << prompt;
    std::getline(std::cin, res);
    while(res.length() == 0){
        std::cout << "Empty fields are not allowed\n";
        std::cout << prompt;
        std::getline(std::cin, res);
    }
    return res;
}

std::vector <std::string> SignUpView::display(){
    std::string res;
    std::vector  <std::string> options;

    std::cout << prompts[0].prompt << "\n";

    std::cout << prompts[1].prompt;
    while(true){
        std::getline(std::cin, res);
        if(res == "s") {
            options.emplace_back("student");
            break;
        }else if(res == "p"){
            options.emplace_back("professor");
            break;
        } else
            std::cout << "Choose between p/s:\n";
    }

    options.emplace_back(acceptsInput(prompts[2].prompt)); // name
    options.emplace_back(acceptsInput(prompts[3].prompt)); // username
    options.emplace_back(acceptsInput(prompts[4].prompt)); // password
    if(options[0] == "student")
        options.emplace_back(acceptsInput(prompts[5].prompt));
    else
        options.emplace_back(acceptsInput(prompts[6].prompt));
    return options;
}

std::map <std::string, std::string> SignUpView::parseLine(std::string &line) {
    std::string value;
    std::vector <std::string> userArr;

    while(line.length()){
        if(line[0] == ','){
            userArr.push_back(value);
            value.clear();
        } else {
            value.push_back(line[0]);
        }
        line.erase(line.begin());
    }
    userArr.push_back(value);

    std::map<std::string, std::string> user;
    user["Name"] = userArr[0];
    user["Username"] = userArr[1];
    user["Password"] = userArr[2];
    return user;
}

void SignUpView::createUser(std::vector <std::string>& options){
    std::string fileName;
    if(options[0] == "student")
        fileName = "resources/students.txt";
    else
        fileName = "resources/professors.txt";

    std::ifstream fin(fileName);
    for(std::string line; std::getline(fin, line); ){
        std::map<std::string, std::string> user = parseLine(line);
        if(user["Username"] == options[2] || user["Password"] == options[3])
            throw bad_account{"Cannot create account"};
    }
    fin.close();

    if(options[0] == "student") {   //check if the group exists
        fileName = "resources/groups.txt";
        fin = std::ifstream(fileName);
        bool found = false;
        for (std::string line; std::getline(fin, line) && !found;)
            if (line == options[4])
                found = true;
        fin.close();
        if(!found)
            throw bad_account{"Cannot create account. Group doesn't exist"};

        fileName = "resources/groups/" + options[4] + "Student.txt";
        std::ofstream fout(fileName, std::ios::app);
        fout << options[2] << "\n";
        fout.close();

    } else if(options[0] == "professor"){
        fileName = "resources/subjects.txt";
        fin = std::ifstream(fileName);
        bool found = false;
        int credits;
        for (std::string line; std::getline(fin, line) && !found;) {
            fin >> credits;
            std::cout << line << " " << credits << "\n";
            fin.get();
            if (line == options[4])
                found = true;
        }
        fin.close();
        if(!found)
            throw bad_account{"Cannot create account. Subject doesn't exist"};

        fileName = "resources/professors/" + options[2] + ".txt";
        std::ofstream fout(fileName, std::ios::app);
        fout << options[4] << "\n";
        fout.close();
    }

    fileName = options[0] == "student" ? "resources/students.txt" : "resources/professors.txt";
    std::ofstream fout(fileName, std::ios::app);
    fout << options[1] + "," + options[2] + "," + options[3] + "," + options[4] << "\n";
    fout.close();
}

std::string SignUpView::listen(){
    while(true){
        std::vector <std::string> options = display();
        try{
            createUser(options);
            std::cout << "Account created successfully. You can now sign in.\n";
            return "WelcomeView";
        }
        catch (input_error& err){
            std::cout << "\t" << err.what() << "\n";
        }
    }
}