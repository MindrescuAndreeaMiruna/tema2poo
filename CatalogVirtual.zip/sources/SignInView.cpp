#include <fstream>
#include <utility>
#include "../headers/Exceptions.hpp"
#include "../headers/SignInView.hpp"

SignInView::SignInView(std::string viewName, bool isDisplayed): View(std::move(viewName), isDisplayed) {
    prompts.emplace_back(std::make_pair("Sign In", ""));
    prompts.emplace_back(std::make_pair("Are you a Professor(p)/Student(s): ", "option"));
    prompts.emplace_back(std::make_pair("Username: ", "username"));
    prompts.emplace_back(std::make_pair("Password: ", "password"));
}

std::string SignInView::acceptsInput(const std::string& prompt){
    std::string res;
    std::cout << prompt;
    std::getline(std::cin, res);
    while(res.length() == 0){
        std::cout << "Empty fields are not allowed\n";
        std::cout << prompt;
        std::getline(std::cin, res);
    }
    return res;
}

std::vector <std::string> SignInView::display(){
    std::string res;
    std::vector  <std::string> options;

    std::cout << prompts[0].prompt << "\n";

    std::cout << prompts[1].prompt;
    while(true){
        std::getline(std::cin, res);
        if(res == "s") {
            options.emplace_back("s");
            break;
        }else if(res == "p"){
            options.emplace_back("p");
            break;
        } else
            std::cout << "Choose between p/s:\n";
    }

    options.emplace_back(acceptsInput(prompts[2].prompt)); // username
    options.emplace_back(acceptsInput(prompts[3].prompt)); // password
    return options;
}

std::map <std::string, std::string> SignInView::parseLine(std::string &line) {
    std::string value;
    std::vector <std::string> userArr;

    while(line.length()){
        if(line[0] == ','){
            userArr.push_back(value);
            value.clear();
        } else {
            value.push_back(line[0]);
        }
        line.erase(line.begin());
    }
    userArr.push_back(value);

    std::map<std::string, std::string> user;
    user["Username"] = userArr[1];
    user["Password"] = userArr[2];
    return user;
}

void SignInView::signInUser(std::vector <std::string>& options){
    std::string fileName;
    if(options[0] == "s")
        fileName = "resources/students.txt";
    else
        fileName = "resources/professors.txt";

    bool found = false;
    std::ifstream fin(fileName);
    for(std::string line; std::getline(fin, line) && !found; ){
        std::map<std::string, std::string> user = parseLine(line);
        if(user["Username"] == options[1] && user["Password"] == options[2])
            found = true;
    }
    fin.close();

    if(!found)
        throw missing_account{"This account doesn't exist"};
}

std::string SignInView::listen(){
    while(true){
        std::vector <std::string> options = display();
        try{
            signInUser(options);
            std::cout <<  options[1] << ", you are now signed in.\n";
            return options[0] == "s" ? "StudentView/" + options[1] : "ProfessorView/" + options[1];
        }
        catch (input_error& err){
            std::cout << "\t" << err.what() << "\n";
        }
    }
}