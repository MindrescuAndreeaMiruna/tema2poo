#ifndef POO_CV_PROFESSOR_HPP
#define POO_CV_PROFESSOR_HPP

#include <vector>
#include <string>

class Professor{
private:
    std::string username;
    std::string subject;
    std::vector <std::string> groups;

public:
    explicit Professor(std::string); //username;

    void readFile();

    std::string getUsername() const;
    std::string getSubject() const;
    std::vector <std::string> getGroups() const;

    void addGroup(const std::string&); //I know it is a valid group
};


#endif //POO_CV_PROFESSOR_HPP
