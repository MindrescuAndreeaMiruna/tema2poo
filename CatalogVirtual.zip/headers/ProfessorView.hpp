#ifndef POO_CV_PROFESSORVIEW_HPP
#define POO_CV_PROFESSORVIEW_HPP

#include "View.hpp"
#include "Professor.hpp"
#include <string>

class ProfessorView: public View{
private:
    Professor professor;
public:
    ProfessorView(std::string, bool, std::string);

    static std::vector<std::string> parseLine(std::string);
    std::vector<std::string> display() override;
    std::string listen() override;

    static bool findGroup(const std::string&) ;
    void showPersonalInfo() const;
    static void seeGroupInfo(const std::string&) ;
    void joinGroup(const std::string&);
    static void addGrade(const std::vector <std::string>&) ;
    static void deleteGrade(const std::vector <std::string>&) ;

    ~ProfessorView() override = default;
};

#endif //POO_CV_PROFESSORVIEW_HPP
