#ifndef POO_CV_STUDENT_HPP
#define POO_CV_STUDENT_HPP

#include <vector>
#include <map>
#include "Subject.hpp"

class Student{
private:
    std::string username;
    std::vector<Subject*> subjects;

public:
   explicit Student(std::string); //username;

   void addSubject(int, std::string); // credits, subjectName, professorName
   void addGrade(const std::string&, const std::string&, float); // subjectName, label, grade
   void deleteGrade(const std::string&, const std::string&); // subjectName, label;
   float getAvgGrade() const;

   static std::map <std::string, std::string> parseLine(std::string);
   static int stringToInt(const std::string&);
   void readFile();
   void writeFile();

   ~Student();

   friend std::ostream& operator<<(std::ostream&, Student&);
};

#endif //POO_CV_STUDENT_HPP
