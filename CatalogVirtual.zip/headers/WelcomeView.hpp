#ifndef POO_CV_WELCOMEVIEW_HPP
#define POO_CV_WELCOMEVIEW_HPP

#include "View.hpp"

class WelcomeView:  public View{
public:
    WelcomeView(std::string, bool);

    std::string listen() override;
    std::vector <std::string> display() override;
};

#endif //POO_CV_WELCOMEVIEW_HPP
