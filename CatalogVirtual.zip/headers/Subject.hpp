#ifndef POO_CV_SUBJECT_HPP
#define POO_CV_SUBJECT_HPP

#include <string>
#include <vector>

class Subject{
private:
    int credits;
    std::string subjectName;
    std::vector <std::pair<std::string, float>> grades;
public:
    Subject(int, std::string);

    int getCredits() const;
    std::string getSubjectName() const;
    std::vector <std::pair<std::string, float>> getGrades() const;

    void validateLabel(const std::string&) const;
    void addGrade(const std::string&, float);
    void deleteGrade(const std::string&);
    float getAvgGrade();

    friend std::ostream& operator<<(std::ostream&, const Subject&);

    ~Subject() = default;

};

#endif //POO_CV_SUBJECT_HPP
