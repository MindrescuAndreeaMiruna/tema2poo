#ifndef POO_CV_VIEW_HPP
#define POO_CV_VIEW_HPP

#include <iostream>
#include <vector>
#include <string>
#define prompt first
#define label second

class View{
protected:
    std::string viewName;
    std::vector <std::pair < std::string, std::string> > prompts;
    bool isDisplayed;

public:
    View(std::string, bool);

    bool getIsDisplayed() const;
    void setIsDisplayed(bool);
    std::string getViewName() const;

    virtual std::vector<std::string> display() = 0;
    virtual std::string listen() = 0;

    virtual ~View() = default;

};

#endif //POO_CV_VIEW_HPP
