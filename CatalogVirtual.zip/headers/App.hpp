#ifndef POO_CV_APP_HPP
#define POO_CV_APP_HPP

#include "View.hpp"
#include <string>
#include <vector>

class App{
private:
    std::vector<View*> views;
public:
    App();

    void changeView(const std::string&);
    void run();

    ~App();
};

#endif //POO_CV_APP_HPP
