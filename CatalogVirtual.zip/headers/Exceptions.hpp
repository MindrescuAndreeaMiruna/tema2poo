#ifndef POO_CV_EXCEPTIONS_HPP
#define POO_CV_EXCEPTIONS_HPP

#include <exception>
#include <string>
#include <utility>
#include <cstring>

class input_error: public std::exception{
protected:
    std::string message;
public:
    explicit input_error(std::string message): message(std::move(message)){}
    [[nodiscard]] const char * what() const noexcept override = 0;
};

class bad_account: public input_error{
public:
    explicit bad_account(std::string message): input_error(std::move(message)){}
    [[nodiscard]] const char * what() const noexcept override{
        std::string ret_message = "bad_account: " + message;
        char *p = new char[ret_message.length() + 1];
        std::strcpy(p, ret_message.c_str());
        return p;
    }
};

class missing_account: public input_error{
public:
    explicit missing_account(std::string message): input_error(std::move(message)){}
    [[nodiscard]] const char * what() const noexcept override{
        std::string ret_message = "missing_account: " + message;
        char *p = new char[ret_message.length() + 1];
        std::strcpy(p, ret_message.c_str());
        return p;
    }
};

class invalid_input: public input_error{
public:
    explicit invalid_input(std::string message): input_error(std::move(message)){}
    [[nodiscard]] const char * what() const noexcept override{
        std::string ret_message = "invalid_input: " + message;
        char *p = new char[ret_message.length() + 1];
        std::strcpy(p, ret_message.c_str());
        return p;
    }
};

#endif //POO_CV_EXCEPTIONS_HPP
