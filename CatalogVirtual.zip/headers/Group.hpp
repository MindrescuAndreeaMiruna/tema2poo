#ifndef POO_CV_GROUP_HPP
#define POO_CV_GROUP_HPP

#include <vector>
#include <string>
#include "Student.hpp"
#include "Professor.hpp"

class Group{
private:
    std::vector<std::string> professors;
    std::vector<std::string> students;
    std::vector <std::string> subjects;
    std::string groupName;
public:
    explicit Group(const std::string&);

    static void readFile(const std::string&, std::vector <std::string>&);
    static void writeFile(const std::string&, std::vector <std::string>&);

    std::string getGroupName();

    void addStudent(const std::string&); // studentUserName
    void addProfessor(const std::string&); //professorUserName
    void addSubject(const std::string&); //subjectName

    void findSubject(const std::string&); //subjectName

    ~Group();
};

#endif //POO_CV_GROUP_HPP
