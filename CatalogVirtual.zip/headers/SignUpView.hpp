#ifndef POO_CV_SIGNUPVIEW_HPP
#define POO_CV_SIGNUPVIEW_HPP

#include <map>
#include "View.hpp"

class SignUpView: public View{
public:
    SignUpView(std::string, bool);

    static std::string acceptsInput(const std::string&);
    static std::map <std::string, std::string> parseLine(std::string&);
    static void createUser(std::vector <std::string>&);

    std::vector <std::string> display() override;
    std::string listen() override;

    ~SignUpView() override = default;
};

#endif //POO_CV_SIGNUPVIEW_HPP
