#ifndef POO_CV_SIGNINVIEW_HPP
#define POO_CV_SIGNINVIEW_HPP

#include <map>
#include "../headers/View.hpp"

class SignInView: public View{
public:
    SignInView(std::string, bool);

    static std::string acceptsInput(const std::string&);
    static std::map <std::string, std::string> parseLine(std::string&);
    static void signInUser(std::vector <std::string>&);

    std::vector <std::string> display() override;
    std::string listen() override;

    ~SignInView() override = default;
};

#endif //POO_CV_SIGNINVIEW_HPP
