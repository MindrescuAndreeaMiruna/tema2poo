#ifndef POO_CV_STUDENTVIEW_HPP
#define POO_CV_STUDENTVIEW_HPP

#include "View.hpp"
#include "Student.hpp"
#include <string>

class StudentView: public View{
private:
    Student student;
public:
    StudentView(std::string, bool, std::string); //viewName, isDisplayed, username

    std::vector<std::string> display() override;
    std::string listen() override;

    ~StudentView() override = default;
};

#endif //POO_CV_STUDENTVIEW_HPP
